psql property -c 'select * from q2;'
