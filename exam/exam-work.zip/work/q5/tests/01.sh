python3 ./q5 Apartment 1000000 2 1 0
