python3 ./q5 House 5000000 5 4 3
