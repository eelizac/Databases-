python3 ./q5 Apartment 500000 0 0 0
