python3 ./q5 Apartment 1500000 3 2 1
