python3 ./q5 Townhouse 1500000 2 1 0
