python3 ./q5 Apartment 850000 0 0 0
