psql property -c 'select address(id) from properties where length(address(id)) < 27;'
