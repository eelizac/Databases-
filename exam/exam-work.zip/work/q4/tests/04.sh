psql property -c 'select id, address(id) from properties where id between 46400 and 46405 order by id;'
