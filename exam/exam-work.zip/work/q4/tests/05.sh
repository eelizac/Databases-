psql property -c 'select id,ptype,address(id) from properties order by id limit 10;'
