psql property -c 'select address(46000);'
