psql property -c 'select * from q3;'
