psql footy -c 'select * from q3 order by team'
