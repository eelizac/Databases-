echo 'select * from q1 order by team;' | psql footy
