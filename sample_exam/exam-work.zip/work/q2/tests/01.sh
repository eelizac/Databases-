psql footy -c 'select * from q2 order by player, ngoals desc'
