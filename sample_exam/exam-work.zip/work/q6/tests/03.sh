./q6 "China" 2005
