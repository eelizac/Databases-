psql footy -c "select * from q5('No Team');"
