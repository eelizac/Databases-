psql footy -c "select * from q5('England');"
