./q7 'Pedro Navarro'
