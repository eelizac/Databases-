psql footy -c "select * from q4('Japan','Korea');"
